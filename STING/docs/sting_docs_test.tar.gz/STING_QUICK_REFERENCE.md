# STING Platform Quick Reference

## What is STING?

**STING (Secure Technological Intelligence and Networking Guardian)** is a comprehensive enterprise AI platform that provides secure, private access to advanced language models and knowledge management capabilities.

## Key Features

- **🔒 Enterprise Security**: Complete on-premises deployment with zero external dependencies
- **🤖 Advanced AI**: Integration with multiple language models including Phi-3, Llama, and more  
- **🍯 Honey Jar Knowledge System**: Proprietary knowledge management with vector search
- **🔐 Passkey Authentication**: Modern passwordless security with Ory Kratos
- **🐝 Bee AI Assistant**: Intelligent chatbot with contextual awareness
- **📊 Analytics & Monitoring**: Comprehensive observability with Grafana and Loki

## Architecture Overview

STING is built on a modern microservices architecture:

### Core Services
- **Frontend**: React 18 with modern UI components (Port 8443)
- **Backend API**: Flask/Python with PostgreSQL database (Port 5050)
- **Authentication**: Ory Kratos for secure user management (Ports 4433/4434)
- **Database**: PostgreSQL for application data (Port 5432)
- **Secrets Management**: HashiCorp Vault (Port 8200)

### AI & Knowledge Services  
- **AI Services**: Multiple LLM backends with intelligent routing
- **Knowledge Service**: Vector-based semantic search with ChromaDB (Port 8090)
- **Chatbot (Bee)**: AI assistant with contextual awareness (Port 8888)
- **External AI**: Bridge to external models (Port 8091)

### Infrastructure
- **Docker Compose**: Container orchestration  
- **Redis**: Session storage and caching (Port 6379)
- **Observability**: Grafana, Loki, and Promtail for monitoring

## Core Components

### 🍯 Honey Jar Knowledge System
The signature feature of STING - a sophisticated knowledge management system:
- **Purpose**: Secure document storage with semantic search
- **Technology**: Vector embeddings with ChromaDB
- **Types**: Public, private, and premium knowledge bases
- **Formats**: Supports PDF, DOCX, HTML, JSON, Markdown, TXT
- **Integration**: Enhances Bee assistant responses with contextual knowledge

### 🐝 Bee AI Assistant
Your intelligent AI companion:
- **Capabilities**: Natural language processing, contextual awareness
- **Knowledge**: Accesses Honey Jar content for accurate responses
- **Tools**: Can perform actions and integrations
- **Security**: Respects user permissions and access controls

### 🔐 Security Features
- **Authentication**: Ory Kratos with password and passkey support
- **Authorization**: Role-based access control (Admin, User roles)
- **TOTP 2FA**: Time-based one-time passwords for admin accounts
- **Session Management**: Secure session handling with Redis storage
- **Data Privacy**: On-premises deployment, no external data sharing

## Getting Started

### Installation
```bash
# Clone the repository
git clone <sting-repo-url>
cd STING

# Install prerequisites
./pre_install.sh

# Install STING
./install_sting.sh install --debug
```

### Basic Operations
```bash
# Service Management
./manage_sting.sh start          # Start all services
./manage_sting.sh stop           # Stop services  
./manage_sting.sh restart        # Restart services
./manage_sting.sh status         # Check service health

# Development
./manage_sting.sh logs [service] # View logs
./manage_sting.sh update [service] # Update specific service
```

### Access Points
- **Web Interface**: https://localhost:8443
- **API Documentation**: https://localhost:5050/api/
- **Admin Interface**: Available after admin login

## Use Cases

### Enterprise Applications
- **Secure AI Deployment**: Private AI for sensitive data processing
- **Knowledge Management**: Searchable document repositories
- **Intelligent Assistance**: AI-powered help and automation
- **Secure Communication**: Private messaging and collaboration

### Compliance & Privacy
- **Data Sovereignty**: Complete on-premises control
- **Regulatory Compliance**: GDPR, HIPAA, SOX compatible
- **Privacy Protection**: No external data transmission
- **Audit Trail**: Comprehensive logging and monitoring

## Key Benefits

1. **Security First**: Enterprise-grade security from the ground up
2. **Privacy Preserved**: Complete data sovereignty and control
3. **Scalable Architecture**: Microservices design for growth
4. **Modern Technology**: Latest AI models and frameworks
5. **User Experience**: Intuitive interface with powerful capabilities
6. **Extensible**: Plugin architecture for custom integrations

## Support & Documentation

- **Documentation**: Comprehensive guides in `/docs` directory
- **Architecture**: Detailed technical specifications available
- **API Reference**: Complete API documentation included
- **User Guides**: Step-by-step instructions for all features
- **Troubleshooting**: Common issues and solutions documented

## Target Users

- **Enterprise Organizations**: Large companies needing secure AI
- **Government Agencies**: Classified data and compliance requirements
- **Healthcare**: HIPAA-compliant AI processing
- **Financial Services**: Regulatory compliance and risk management
- **Legal Firms**: Secure document analysis and research
- **Technology Teams**: Developers and IT professionals

STING represents the future of secure, private enterprise AI - combining cutting-edge technology with the security and control that organizations demand.