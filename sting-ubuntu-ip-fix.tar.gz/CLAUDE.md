# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

STING-CE (Secure Trusted Intelligence and Networking Guardian - Community Edition) is a self-hosted platform for secure, private LLM deployment with complete data sovereignty. It features innovative "Honey Jar" knowledge management, enterprise-grade authentication via Ory Kratos, and the Bee AI assistant.

**Core Value**: Enterprise-ready AI deployment with complete data sovereignty, modern passwordless authentication, and semantic knowledge management.

**Key Differentiator**: Bee-themed knowledge management system ("Honey Jars") with vector search capabilities built on ChromaDB.

## Architecture

### Microservices Stack
- **Frontend**: React 18 + Vite + Material-UI (port 8443 HTTPS)
- **Backend API**: Flask + SQLAlchemy + PostgreSQL (port 5050 HTTPS)
- **Authentication**: Ory Kratos v1.3.0 with WebAuthn/Passkeys (ports 4433/4434)
- **AI Services**:
  - Bee Chatbot (port 8888)
  - External AI Service - Ollama interface (port 8091)
  - LLM Gateway Proxy (port 8085)
- **Knowledge System**:
  - Knowledge Service - FastAPI (port 8090)
  - ChromaDB vector database (port 8000)
- **Infrastructure**:
  - PostgreSQL 16 with separate databases (app, kratos, messaging)
  - HashiCorp Vault for secrets management
  - Redis 7 for caching and queuing
  - Nginx for reverse proxy
  - Mailpit for development email testing

### Service Communication
Services communicate via Docker internal network (`sting_local`):
- Internal hostnames: `db`, `kratos`, `app`, `knowledge`, `chatbot`, `messaging`, etc.
- External host access: `host.docker.internal` (for accessing host-based services like Ollama)
- Port mapping: Internal ports may differ from external (e.g., PostgreSQL 5432→5433)

## Essential Commands

### Installation & Setup
```bash
# One-line installation
bash -c "$(curl -fsSL https://raw.githubusercontent.com/AlphaBytez/STING-CE-Public/main/bootstrap.sh)"

# Manual installation
git clone https://github.com/AlphaBytez/STING-CE-Public.git
cd STING-CE-Public
./install_sting.sh

# Reinstall (preserves data)
./manage_sting.sh reinstall

# Fresh install (removes everything)
./manage_sting.sh reinstall --fresh
```

### Service Management
```bash
# From repository root or STING/ directory
./manage_sting.sh start              # Start all services
./manage_sting.sh stop               # Stop all services
./manage_sting.sh restart [service]  # Restart service(s)
./manage_sting.sh status             # Check service health
./manage_sting.sh logs [service]     # View logs (omit service for all)
./manage_sting.sh update [service]   # Rebuild and restart service
```

### Development
```bash
# Frontend development
cd STING/frontend
npm install
npm start                    # Dev server on port 8443
npm run lint                 # ESLint checking
npm test                     # Jest tests
npm run build                # Production build

# Backend development
cd STING
source venv/bin/activate     # If using virtualenv
python -m pytest app/tests/  # Run tests
```

### LLM & AI Services
```bash
# Modern Ollama-based stack (recommended)
./manage_sting.sh install-ollama     # Install Ollama + default models
./manage_sting.sh ollama-status      # Check Ollama status
./manage_sting.sh llm-status         # Check all LLM services

# Ollama CLI (if installed on host)
ollama list                          # List installed models
ollama pull phi3:mini                # Install model
ollama run phi3:mini                 # Test model
```

### Database Operations
```bash
# Connect to databases
psql -h localhost -p 5433 -U postgres -d sting_app       # App database
psql -h localhost -p 5433 -U postgres -d kratos          # Kratos database
psql -h localhost -p 5433 -U postgres -d sting_messaging # Messaging database

# View database credentials
cat ${INSTALL_DIR}/env/db.env
```

### Configuration Management
```bash
# Regenerate environment files after config.yml changes
./manage_sting.sh regenerate-env

# Test configuration generation (uses utils container)
COMPOSE_FILE=${INSTALL_DIR}/docker-compose.yml docker compose --profile installation up -d utils
docker exec sting-ce-utils bash -c "cd /app/conf && INSTALL_DIR=/app python3 config_loader.py config.yml --mode bootstrap"
```

## Project Structure

```
STING-CE-Public/
├── STING/                          # Main application directory
│   ├── app/                        # Flask backend application
│   │   ├── routes/                 # API route handlers (50+ route files)
│   │   ├── models/                 # SQLAlchemy ORM models
│   │   ├── services/               # Business logic layer
│   │   ├── middleware/             # Request/response middleware
│   │   ├── workers/                # Background workers
│   │   └── migrations/             # Database migrations
│   ├── frontend/                   # React frontend (Vite + Material-UI)
│   │   ├── src/
│   │   │   ├── components/        # Reusable React components
│   │   │   ├── pages/             # Page-level components
│   │   │   ├── services/          # API client services
│   │   │   └── utils/             # Utility functions
│   │   └── public/                # Static assets
│   ├── knowledge_service/         # Honey Jar knowledge management (FastAPI)
│   │   ├── core/                  # Nectar processor, honeycomb manager
│   │   ├── auth/                  # Auth integration
│   │   └── models/                # Pydantic models
│   ├── chatbot/                   # Bee AI assistant service
│   │   ├── bee_server.py          # Main chatbot server
│   │   ├── prompts/               # AI prompt templates
│   │   └── tools/                 # Tool integrations
│   ├── external_ai_service/       # Ollama interface service
│   ├── messaging_service/         # Inter-service messaging
│   ├── public_bee/                # Public-facing Bee API
│   ├── vault/                     # HashiCorp Vault config
│   ├── kratos/                    # Ory Kratos identity config
│   │   ├── identity.schema.*.json # Identity schemas
│   │   ├── kratos.yml             # Main Kratos configuration
│   │   └── courier-templates/     # Email templates
│   ├── conf/                      # Configuration management
│   │   ├── config.yml             # Main configuration file
│   │   └── config_loader.py       # Env file generator
│   ├── lib/                       # Shell library modules
│   │   ├── bootstrap.sh           # Initial setup functions
│   │   ├── services.sh            # Service management
│   │   ├── installation.sh        # Installation logic
│   │   ├── health.sh              # Health check functions
│   │   └── hive_diagnostics/      # Diagnostic bundle system
│   ├── scripts/                   # Utility scripts
│   │   ├── admin/                 # Admin utilities
│   │   ├── health/                # Health check scripts
│   │   └── setup/                 # Setup scripts
│   ├── docs/                      # Documentation
│   │   ├── architecture/          # System architecture docs
│   │   ├── features/              # Feature documentation
│   │   ├── guides/                # User guides
│   │   └── api/                   # API documentation
│   ├── docker-compose.yml         # Main service orchestration
│   ├── docker-compose.full.yml    # Full stack with observability
│   ├── manage_sting.sh            # Main management script
│   └── install_sting.sh           # Installation script
├── bootstrap.sh                    # One-line installer entry point
├── manage_sting.sh                 # Root-level wrapper script
├── install_sting.sh                # Root-level installer wrapper
└── README.md                       # Project documentation
```

## Configuration System

### Main Configuration (`STING/conf/config.yml`)
Controls all aspects of the platform:
- System settings (domain, protocol, ports)
- Feature flags (knowledge, observability, etc.)
- Security settings (AAL2 timeout, PII protection)
- LLM configuration (provider, models, endpoints)
- Database connection settings
- Health check intervals
- Resource limits

### Environment File Generation
The `config_loader.py` script generates service-specific `.env` files in `${INSTALL_DIR}/env/`:
- `db.env` - PostgreSQL credentials and connection info
- `kratos.env` - Kratos authentication settings
- `vault.env` - Vault configuration
- `frontend.env` - React app environment variables
- `app.env` - Flask application settings
- `chatbot.env` - Bee chatbot configuration
- `knowledge.env` - Knowledge service settings
- `external-ai.env` - External AI service settings

**Important**: After editing `config.yml`, run `./manage_sting.sh regenerate-env` to update env files.

## Key Implementation Details

### Authentication Flow
1. User accesses frontend at https://localhost:8443
2. Frontend checks for session via `/api/auth/session`
3. If no session, redirect to Kratos login flow
4. Kratos handles authentication (password, magic link, WebAuthn, TOTP)
5. On success, Kratos creates session in PostgreSQL
6. Frontend stores session cookie and validates with backend
7. Backend middleware validates every request against Kratos

**Key Files**:
- `app/middleware/kratos_auth_middleware.py` - Session validation
- `app/routes/auth_routes.py` - Auth API endpoints
- `kratos/kratos.yml` - Kratos configuration
- `frontend/src/services/authService.js` - Frontend auth client

### Honey Jar Knowledge System

The bee-themed knowledge management system with semantic search:

**Components**:
- **Nectar Processor**: Document ingestion and text extraction
- **Honeycomb Manager**: ChromaDB vector database interface
- **Pollination Engine**: Semantic search and retrieval
- **Hive Manager**: Knowledge base administration

**Supported Formats**: PDF, DOCX, HTML, JSON, Markdown, TXT

**Key Files**:
- `knowledge_service/core/nectar_processor.py` - Document processing
- `knowledge_service/core/honeycomb_manager.py` - Vector storage
- `knowledge_service/core/pollination_engine.py` - Search engine
- `app/models/honey_jar_models.py` - Database models

**API Endpoints**:
- `POST /honey-jars` - Create knowledge base
- `POST /honey-jars/{id}/documents` - Upload documents
- `POST /search` - Semantic search
- `POST /bee/context` - Get context for Bee

### LLM Architecture

**Modern Stack (Recommended)**:
```
User → Bee Chatbot → External AI Service → Ollama → Models (phi3, deepseek-r1)
```

**Service Endpoints**:
- Bee Chatbot: http://localhost:8888
- External AI: http://localhost:8091
- Ollama: http://localhost:11434

**Key Files**:
- `chatbot/bee_server.py` - Main chatbot server
- `external_ai_service/` - Ollama interface
- `chatbot/prompts/` - AI prompt templates

### Database Architecture

**Three Separate Databases**:
1. `sting_app` - Main application data (users, honey jars, conversations)
2. `kratos` - Identity and session data
3. `sting_messaging` - Inter-service messaging

**User Isolation**:
- `postgres` - Superuser
- `app_user` - Application access to sting_app
- `kratos_user` - Kratos-only access

**Connection Info**:
- External port: 5433 (maps to internal 5432)
- Credentials stored in `${INSTALL_DIR}/env/db.env`

## Development Workflow

### Making Code Changes

**Backend Changes** (Flask API):
1. Edit files in `STING/app/`
2. Rebuild container: `./manage_sting.sh update app`
3. Check logs: `./manage_sting.sh logs app`

**Frontend Changes** (React):
1. Edit files in `STING/frontend/src/`
2. For development: `cd STING/frontend && npm start`
3. For production: `./manage_sting.sh update frontend`

**Configuration Changes**:
1. Edit `STING/conf/config.yml`
2. Run `./manage_sting.sh regenerate-env`
3. Restart services: `./manage_sting.sh restart`

**Database Changes**:
1. Create migration in `STING/app/migrations/`
2. Update models in `STING/app/models/`
3. Rebuild app service: `./manage_sting.sh update app`

### Service Endpoints (Development)

- **Frontend**: https://localhost:8443
- **Backend API**: https://localhost:5050/api/
- **Kratos Public**: https://localhost:4433/
- **Kratos Admin**: https://localhost:4434/
- **Bee Chatbot**: http://localhost:8888/
- **Knowledge Service**: http://localhost:8090/
- **External AI**: http://localhost:8091/
- **ChromaDB**: http://localhost:8000/
- **Vault UI**: http://localhost:8200/
- **Redis**: localhost:6379
- **Mailpit** (dev): http://localhost:8025/

## Common Tasks

### Adding a New API Endpoint
1. Create route function in `STING/app/routes/[feature]_routes.py`
2. Register blueprint in `STING/app/__init__.py`
3. Add authentication middleware if needed
4. Update API documentation
5. Write tests in `STING/app/tests/`

### Adding a New Frontend Page
1. Create component in `STING/frontend/src/pages/[Feature]Page.jsx`
2. Add route in `STING/frontend/src/App.js`
3. Create API service in `STING/frontend/src/services/[feature]Service.js`
4. Add navigation link if applicable
5. Write tests in Jest

### Adding a New Microservice
1. Create service directory with Dockerfile
2. Add service definition to `docker-compose.yml`
3. Add configuration section to `conf/config.yml`
4. Update `conf/config_loader.py` for env file generation
5. Add health check endpoint (`/health`)
6. Register in `lib/services.sh` for startup
7. Add to `lib/installation.sh` build sequence
8. Update this CLAUDE.md file

### Running Tests

**Frontend Tests**:
```bash
cd STING/frontend
npm test                    # Run all tests
npm test -- --coverage      # With coverage
npm test [Component].test   # Specific test
```

**Backend Tests**:
```bash
cd STING
python -m pytest app/tests/              # All tests
python -m pytest app/tests/test_auth.py  # Specific test
python -m pytest -v                      # Verbose output
```

**Integration Tests**:
```bash
./manage_sting.sh status    # Verify all services healthy
# Then run specific test scripts in STING/scripts/
```

## Troubleshooting

### Common Issues

**Services not starting**:
```bash
./manage_sting.sh status           # Check which services are down
./manage_sting.sh logs [service]   # Check logs for errors
docker ps -a | grep sting-ce       # Check container status
```

**Database connection errors**:
```bash
# Verify database is healthy
docker exec sting-ce-db pg_isready -U postgres

# Check credentials
cat ${INSTALL_DIR}/env/db.env

# Test connection
psql -h localhost -p 5433 -U postgres -d sting_app
```

**Authentication not working**:
```bash
# Check Kratos status
curl -k https://localhost:4434/admin/health/ready

# View Kratos logs
./manage_sting.sh logs kratos

# Verify session in database
psql -h localhost -p 5433 -U postgres -d kratos -c "SELECT id, created_at FROM sessions;"
```

**Bee chatbot not responding**:
```bash
# Check chatbot health
curl http://localhost:8888/health

# Check Ollama is running
curl http://localhost:11434/api/tags

# View chatbot logs
./manage_sting.sh logs chatbot
```

**Knowledge service errors**:
```bash
# Check knowledge service health
curl http://localhost:8090/health

# Check ChromaDB
curl http://localhost:8000/api/v1/heartbeat

# View knowledge logs
./manage_sting.sh logs knowledge
```

### Debugging Tools

**Log Analysis**:
```bash
./manage_sting.sh logs [service]         # View logs
./manage_sting.sh logs [service] -f      # Follow logs
./manage_sting.sh logs [service] --tail 100  # Last 100 lines
```

**Container Inspection**:
```bash
docker exec -it sting-ce-[service] /bin/bash  # Shell access
docker inspect sting-ce-[service]              # Full container info
docker stats sting-ce-[service]                # Resource usage
```

**Database Debugging**:
```bash
# Connect to database
psql -h localhost -p 5433 -U postgres -d sting_app

# Common queries
\dt                                    # List tables
\d+ table_name                         # Describe table
SELECT * FROM users LIMIT 10;          # View data
```

## Security Considerations

### Secrets Management
- All secrets stored in HashiCorp Vault
- Access via hvac Python client
- Never commit secrets to Git
- Use environment variables for sensitive config

### API Security
- All endpoints require authentication (unless explicitly public)
- Kratos session validation via middleware
- API keys for programmatic access (`app/models/api_key_models.py`)
- CORS configured for frontend domain only

### Data Protection
- PII detection and serialization in messages
- Automatic sanitization of logs
- Encrypted communication between services
- Audit logging for compliance

## Development Best Practices

### Code Style
- **Python**: Follow PEP 8, use Black formatter
- **JavaScript**: Follow Airbnb style guide, use ESLint
- **Naming**:
  - Python: `snake_case` for functions/variables, `PascalCase` for classes
  - JavaScript: `camelCase` for functions/variables, `PascalCase` for components
  - Database: `snake_case` for tables and columns

### Git Workflow
- Use conventional commits: `feat:`, `fix:`, `docs:`, `refactor:`
- Create feature branches from `main`
- Update documentation with code changes
- Never commit `.env` files or secrets

### Docker Best Practices
- Every service must have `/health` endpoint
- Define memory and CPU limits
- Use named volumes for persistent data
- Handle SIGTERM for graceful shutdown
- Log to stdout/stderr for Docker collection

### Testing
- Write unit tests for new functionality
- Test API endpoints with curl or Postman
- Verify health checks work before deploying
- Use Mailpit for email testing in development

## Additional Resources

- **Main Documentation**: `STING/docs/README.md`
- **Architecture Docs**: `STING/docs/architecture/`
- **API Reference**: `STING/docs/api/`
- **Feature Guides**: `STING/docs/features/`
- **Installation Guide**: `STING/docs/platform/guides/fresh-install-guide.md`
- **Security Policy**: `SECURITY.md`
- **Contributing Guide**: `CONTRIBUTING.md`

## Support

- **GitHub Issues**: https://github.com/AlphaBytez/STING-CE-Public/issues
- **Security**: security@alphabytez.dev
- **General**: olliec@alphabytez.dev
